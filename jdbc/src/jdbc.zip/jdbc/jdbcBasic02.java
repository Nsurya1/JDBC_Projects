package jdbc;
import java.sql.*;

public class jdbcBasic02 {
 public void main(String args[]) throws Exception {
	 String url = "jdbc:mysql://localhost:3306/collage";
	 String userName = "root";
	 String password ="nitesh@123";

	 String query = "Insert into student values(107, 'mohit', 25)";
	 
	 Class.forName("com.mysql.cj.jdbc.Driver");
	 Connection con = DriverManager.getConnection(url,userName,password);
	 Statement st = con.createStatement();
	 
	 int count = st.executeUpdate(query);
	 
	 System.out.println(count + " row's effected");
	 st.close();
	 con.close();
 }
}
